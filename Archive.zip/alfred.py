#Setup stuff
import asyncio
import json
import discord
from discord.ext import commands
import random
from urllib.request import urlopen

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

#Pull from config
with open("config.json") as f:
    data = json.load(f)

BOT_TOKEN = data["bot-token"]
CHANNEL_ID = data["channel-id"]
PREFIX = data["command-prefix"]

#Who knows why the fuck this is necessary
bot = commands.Bot(command_prefix=PREFIX, intents=discord.Intents.all())
bot.remove_command('help')

@bot.event
async def on_ready():
    print("Alfred online")
    channel = bot.get_channel(CHANNEL_ID)

@bot.command()
async def info(ctx):
    help = discord.Embed(title="Help:")

    help.add_field(name="Command prefix: ~", value="Please put this before the request", inline = False)

    help.add_field(name="Pokedex commands:", value="poke rand: Returns a random pokemon\npoke (num or name): Returns a specific pokemon", inline=False)

    help.add_field(name="Tarot commands:", value="tarot(x): Returns x amount of Tarot cards", inline=False)

    await ctx.send(embed=help)


@bot.command()
async def poke(ctx,arg):

    pokeLowerList = open("nameLower.txt", "r")
    pokeLowerListDatat = pokeLowerList.read()
    pokeLowerListData = pokeLowerListDatat.split(',')

    pokeList = open("name.txt", "r")
    pokeListDatat = pokeList.read()
    pokeListData = pokeListDatat.split(',')

    pokeTypeList = open("type.txt", "r")
    pokeTypeDatat = pokeTypeList.read()
    pokeTypeData = pokeTypeDatat.split(',')

    uInput = arg


    if uInput.isnumeric():
        pokeNumberData = str(uInput).zfill(3)

        query = (int(pokeNumberData) - 1)

        pokeTypeSplit = pokeTypeData[query].split(' | ')
        firstType = pokeTypeSplit[0]

        if firstType.strip() == "Grass":
            typeColor = 0x007400

        elif firstType.strip() == "Poison":
            typeColor = 0xC000FF

        elif firstType.strip() == "Fire":
            typeColor = 0xFF0000

        elif firstType.strip() == "Flying":
            typeColor = 0x73A7D6

        elif firstType.strip() == "Water":
            typeColor = 0x0071D8

        elif firstType.strip() == "Bug":
            typeColor = 0x579857

        elif firstType.strip() == "Normal":
            typeColor = 0x767676

        elif firstType.strip() == "Electric":
            typeColor = 0xFFFF00

        elif firstType.strip() == "Ground":
            typeColor = 0x675418

        elif firstType.strip() == "Fairy":
            typeColor = 0xFFC0CB

        elif firstType.strip() == "Fighting":
            typeColor = 0x983838

        elif firstType.strip() == "Psychic":
            typeColor = 0xFF3A9C

        elif firstType.strip() == "Rock":
            typeColor = 0xA17950

        elif firstType.strip() == "Steel":
            typeColor = 0xCCCCCC

        elif firstType.strip() == "Ice":
            typeColor = 0x00FFFF

        elif firstType.strip() == "Ghost":
            typeColor = 0x3D47C6

        elif firstType.strip() == "Dragon":
            typeColor = 0x8087E1

        elif firstType.strip() == "Dark":
            typeColor = 0x3E1F00

        image = 'https://www.serebii.net/pokemon/art/' + pokeNumberData + '.png'
        embed = discord.Embed(colour=typeColor)
        embed.add_field(name=pokeListData[query], value="Type: " + pokeTypeData[query] + "\nNumber: " + pokeNumberData)

#debug
        print (query)
        print ("Name: " + pokeListData[query])
        print ("Number: " + pokeNumberData)
        print ("Type: " + pokeTypeData[query])
        print("You entered: " + pokeNumberData + " and it was numeric")
#/debug


    elif uInput.lower() == "rand":

        randNum = random.randint(1, 1025)

        pokeNumberData = str(randNum).zfill(3)

        query = (int(pokeNumberData) - 1)

        #embed color by type

        pokeTypeSplit = pokeTypeData[query].split(' | ')
        firstType = pokeTypeSplit[0]

        if firstType.strip() == "Grass":
            typeColor = 0x007400

        elif firstType.strip() == "Poison":
            typeColor = 0xC000FF

        elif firstType.strip() == "Fire":
            typeColor = 0xFF0000

        elif firstType.strip() == "Flying":
            typeColor = 0x73A7D6

        elif firstType.strip() == "Water":
            typeColor = 0x0071D8

        elif firstType.strip() == "Bug":
            typeColor = 0x579857

        elif firstType.strip() == "Normal":
            typeColor = 0x767676

        elif firstType.strip() == "Electric":
            typeColor = 0xFFFF00

        elif firstType.strip() == "Ground":
            typeColor = 0x675418

        elif firstType.strip() == "Fairy":
            typeColor = 0xFFC0CB

        elif firstType.strip() == "Fighting":
            typeColor = 0x983838

        elif firstType.strip() == "Psychic":
            typeColor = 0xFF3A9C

        elif firstType.strip() == "Rock":
            typeColor = 0xA17950

        elif firstType.strip() == "Steel":
            typeColor = 0xCCCCCC

        elif firstType.strip() == "Ice":
            typeColor = 0x00FFFF

        elif firstType.strip() == "Ghost":
            typeColor = 0x3D47C6

        elif firstType.strip() == "Dragon":
            typeColor = 0x8087E1

        elif firstType.strip() == "Dark":
            typeColor = 0x3E1F00


        image = 'https://www.serebii.net/pokemon/art/' + pokeNumberData + '.png'
        embed = discord.Embed(colour=typeColor)
        embed.add_field(name=pokeListData[query], value="Type: " + pokeTypeData[query] + "\nNumber: " + pokeNumberData)

#debug
        print (query)
        print ("Name: " + pokeListData[query])
        print ("Number: " + pokeNumberData)
        print ("Type: " + pokeTypeData[query])
        print("You entered: " + pokeNumberData + " and it was numeric")
#/debug

    else:
        inLower = uInput.lower()
        pokeNum = (pokeLowerListData.index(inLower) + 1)
        pokeNumberData = str(pokeNum).zfill(3)

        query = (int(pokeNumberData) - 1)

        #embed color by type

        pokeTypeSplit = pokeTypeData[query].split(' | ')
        firstType = pokeTypeSplit[0]

        if firstType.strip() == "Grass":
            typeColor = 0x007400

        elif firstType.strip() == "Poison":
            typeColor = 0xC000FF

        elif firstType.strip() == "Fire":
            typeColor = 0xFF0000

        elif firstType.strip() == "Flying":
            typeColor = 0x73A7D6

        elif firstType.strip() == "Water":
            typeColor = 0x0071D8

        elif firstType.strip() == "Bug":
            typeColor = 0x579857

        elif firstType.strip() == "Normal":
            typeColor = 0x767676

        elif firstType.strip() == "Electric":
            typeColor = 0xFFFF00

        elif firstType.strip() == "Ground":
            typeColor = 0x675418

        elif firstType.strip() == "Fairy":
            typeColor = 0xFFC0CB

        elif firstType.strip() == "Fighting":
            typeColor = 0x983838

        elif firstType.strip() == "Psychic":
            typeColor = 0xFF3A9C

        elif firstType.strip() == "Rock":
            typeColor = 0xA17950

        elif firstType.strip() == "Steel":
            typeColor = 0xCCCCCC

        elif firstType.strip() == "Ice":
            typeColor = 0x00FFFF

        elif firstType.strip() == "Ghost":
            typeColor = 0x3D47C6

        elif firstType.strip() == "Dragon":
            typeColor = 0x8087E1

        elif firstType.strip() == "Dark":
            typeColor = 0x3E1F00

        image = 'https://www.serebii.net/pokemon/art/' + str(pokeNumberData) + '.png'
        embed = discord.Embed(colour=typeColor)
        embed.add_field(name=pokeListData[query], value="Type: " + pokeTypeData[query] + "\nNumber: " + pokeNumberData)

#debug
        print ("Number: " + str(pokeNum))
        print ("Name: " + pokeListData[pokeNum - 1])
        print ("Type: " + pokeTypeData[pokeNum - 1])
#/debug

    embed.set_image(url=image)
    await ctx.send(embed = embed)


@bot.command()
async def tarot(ctx, amount: int):




#    deck = "default"


    for i in range(amount):
        #156 cards

        suit=random.randint(1,5)


        if suit != 1:
            card = random.randint(1,14)
            if card == 1:
                pre = "Ace of "
                cardID = "Ace"
            elif card == 2:
                pre = "Two of "
                cardID = "2"
            elif card == 3:
                pre = "Three of "
                cardID = "3"
            elif card == 4:
                pre = "Four of "
                cardID = "4"
            elif card == 5:
                pre = "Five of "
                cardID = "5"
            elif card == 6:
                pre = "Six of "
                cardID = "6"
            elif card == 7:
                pre = "Seven of "
                cardID = "7"
            elif card == 8:
                pre = "Eight of "
                cardID = "8"
            elif card == 9:
                pre = "Nine of "
                cardID = "9"
            elif card == 10:
                pre = "Ten of "
                cardID = "10"
            elif card == 11:
                pre = "Page of "
                cardID = "Page"
            elif card == 12:
                pre = "Knight of "
                cardID = "Knight"
            elif card == 13:
                pre = "Queen of "
                cardID = "Queen"
            elif card == 14:
                pre = "King of "
                cardID = "King"


        else:
            card = random.randint(1,21)
            if card == 1:
                name = "The Fool"
                cardID = "theFool"
            elif card == 2:
                name = "The Magician"
                cardID = "theMagician"
            elif card == 3:
                name = "The High Priestess"
                cardID = "theHighPriestess"
            elif card == 4:
                name = "The Empress"
                cardID = "theEmpress"
            elif card == 5:
                name = "The Emperor"
                cardID = "theEmperor"
            elif card == 6:
                name = "The Hierophant"
                cardID = "theHierophant"
            elif card == 7:
                name = "The Lovers"
                cardID = "theLovers"
            elif card == 8:
                name = "The Chariot"
                cardID = "theChariot"
            elif card == 9:
                name = "Strength"
                cardID = "strength"
            elif card == 10:
                name = "The Hermit"
                cardID = "theHermit"
            elif card == 11:
                name = "Wheel of Fortune"
                cardID = "wheelOfFortune"
            elif card == 12:
                name = "Justice"
                cardID = "justice"
            elif card == 13:
                name = "The Hanged Man"
                cardID = "theHangedMan"
            elif card == 14:
                name = "Death"
                cardID = "death"
            elif card == 15:
                name = "Temperance"
                cardID = "temperance"
            elif card == 16:
                name = "The Devil"
                cardID = "theDevil"
            elif card == 17:
                name = "The Tower"
                cardID = "theTower"
            elif card == 18:
                name = "The Star"
                cardID = "theStar"
            elif card == 19:
                name = "The Moon"
                cardID = "theMoon"
            elif card == 20:
                name = "The Sun"
                cardID = "theSun"
            elif card == 21:
                name = "Judgement"
                cardID = "judgement"
            elif card == 22:
                name ="The World"
                cardID = "theWorld"

        if suit == 2:
            dataFile = open("swordsDescs.txt", "r")
            swordsDescData = dataFile.read()
            suit = "swords"
            name = pre  + suit.capitalize()

            descriptionLines = swordsDescData.splitlines()
            cardDescs = descriptionLines[card]

            swordsDesc = open("swordsDescs.txt", "r")
            swordsDescData = swordsDesc.read()

            swordsDescLines = swordsDescData.splitlines()

            cardData = swordsDescLines[card-1].split(";")

            if card == 11:
                card = "Page"
            elif card == 12:
                card = "Knight"
            elif card == 13:
                card = "Queen"
            elif card == 14:
                card = "King"
            elif card == 1:
                card = "Ace"
            cardID = suit + str(card)

        elif suit == 3:
            dataFile = open("cupsDescs.txt", "r")
            cupsDescData = dataFile.read()
            suit = "cups"
            name = pre  + suit.capitalize()

            descriptionLines = cupsDescData.splitlines()
            cardDescs = descriptionLines[card]

            cupsDesc = open("cupsDescs.txt", "r")
            cupsDescData = cupsDesc.read()

            cupsDescLines = cupsDescData.splitlines()

            cardData = cupsDescLines[card-1].split(";")

            if card == 11:
                card = "Page"
            elif card == 12:
                card = "Knight"
            elif card == 13:
                card = "Queen"
            elif card == 14:
                card = "King"
            elif card == 1:
                card = "Ace"
            cardID = suit + str(card)

        elif suit == 4:
            dataFile = open("coinsDescs.txt", "r")
            coinsDescData = dataFile.read()
            suit = "coins"
            name = pre  + suit.capitalize()

            descriptionLines = coinsDescData.splitlines()
            cardDescs = descriptionLines[card]

            coinsDesc = open("coinsDescs.txt", "r")
            coinsDescData = coinsDesc.read()

            coinsDescLines = coinsDescData.splitlines()

            cardData = coinsDescLines[card-1].split(";")

            if card == 11:
                card = "Page"
            elif card == 12:
                card = "Knight"
            elif card == 13:
                card = "Queen"
            elif card == 14:
                card = "King"
            elif card == 1:
                card = "Ace"
            cardID = suit + str(card)

        elif suit == 5:
            dataFile = open("wandsDescs.txt", "r")
            wandsDescData = dataFile.read()
            suit = "wands"
            name = pre  + suit.capitalize()

            descriptionLines = wandsDescData.splitlines()
            cardDescs = descriptionLines[card]

            wandsDesc = open("wandsDescs.txt", "r")
            wandsDescData = wandsDesc.read()

            wandsDescLines = wandsDescData.splitlines()

            cardData = wandsDescLines[card-1].split(";")

            if card == 11:
                card = "Page"
            elif card == 12:
                card = "Knight"
            elif card == 13:
                card = "Queen"
            elif card == 14:
                card = "King"
            elif card == 1:
                card = "Ace"
            cardID = suit + str(card)

        else:
            otherDesc = open("otherDescs.txt", "r")
            otherDescData = otherDesc.read()

            otherDescLines = otherDescData.splitlines()

            cardData = otherDescLines[card-1].split(";")
            name = name


        pos=random.randint(0,1)
        if pos == 0:
            position = ""
            pic=str(cardID) + ".jpg"
            print(cardData[1])
            finalDesc = cardData[1]
        else:
            position = " Reversed"
            pic=str(cardID) + "r.jpg"
            print(cardData[2])
            finalDesc = cardData[2]


 #       print(name)
 #       print(pos)


        attachment="attachment://" + pic
        out = discord.Embed(title=name + position, description=finalDesc,color=0x00ff00)

        out.set_image(url=attachment)

        await ctx.send(file=discord.File(pic), embed=out)
#        print (pic)




#        print("Suit: ", suit,  " Card: ",  card,  " Position: ",  position)

        #1-22 misc
        #24-37 swords
        #39-52 cups
        #55-68 coins
        #70-83 wands





bot.run(BOT_TOKEN)


